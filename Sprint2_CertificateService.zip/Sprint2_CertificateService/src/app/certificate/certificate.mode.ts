export interface Certificate {
    id?:number;
    certificateName:string;
    issuingOrganization:string;
    issueDate:Date;
    studentId:number;
 

}
